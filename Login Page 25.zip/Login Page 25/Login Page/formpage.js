function check(form)
{
  if(form.UserName.value == "param" && form.password.value == "123456")
  {
    window.open("transpage.html")
  }
}
